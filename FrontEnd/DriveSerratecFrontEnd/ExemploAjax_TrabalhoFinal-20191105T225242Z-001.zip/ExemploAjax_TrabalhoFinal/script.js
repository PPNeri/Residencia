/*function loadData() {
    var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML =
      var resposta = JSON.parse(this.responseText);

      document.getElementById("demo").innerHTML = 
        "<p>"+resposta.logradouro+"</p>"+
        "<p>"+resposta.bairro+"</p>"
      ;
    }
  };
  
  xhttp.open("GET", 
    "https://viacep.com.br/ws/"+cep.value+"/json/", true);
  xhttp.send(); 
  }*/
  
  function loadData() {
    var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //document.getElementById("demo").innerHTML =
      var resposta = JSON.parse(this.responseText);
      console.log(resposta);
      resposta.forEach(element => {
        document.getElementById("demo").innerHTML += 
        "<p>"+element.name+"</p>";  
      });
      
    }
  };
  
  xhttp.open("GET", 
    "https://api.punkapi.com/v2/beers?page=1", true);
  xhttp.send(); 
  }