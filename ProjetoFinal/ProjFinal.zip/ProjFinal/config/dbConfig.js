module.exports={

    dialect:'mysql',
    host:'localhost',
    username:'root',
    password:'01123581321',
    database:'dbProjetoFinal',
    define:{
        timestamps:true,
        underscored:true,

    }

};